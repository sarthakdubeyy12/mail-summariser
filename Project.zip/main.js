
import { initializeApp } from "https://www.gstatic.com/firebasejs/9.4.1/firebase-app.js";
import { getAnalytics } from "https://www.gstatic.com/firebasejs/9.4.1/firebase-analytics.js";
import { getAuth, GoogleAuthProvider, signInWithPopup, signOut } from "https://www.gstatic.com/firebasejs/9.4.1/firebase-auth.js"

const firebaseConfig = {
     apiKey: "AIzaSyC193xjOSHroNrsXl3RQxthNpZuoVdLgL8",
     authDomain: "summarizer-app.firebaseapp.com",
     projectId: "summarizer-gmail-app",
     storageBucket: "summarizer-gmail-app.appspot.com",
     messagingSenderId: "518931430148",
     appId: "1:518931430148:web:85969c92ee07ddc99c2e51",
     measurementId: "G-LXV0W375J1"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);

const provider = new GoogleAuthProvider(app);
const auth = getAuth(app);
auth.languageCode = 'en'

// const google_login = document.getElementById("login");
login.addEventListener('click', function () {
     signInWithPopup(auth, provider)
          .then((result) => {
               const credential = GoogleAuthProvider.credentialFromResult(result);
               const user = result.user;
               console.log(user);;
               window.location.href = "./vmsmain.html";
               // alert(user.displayName);
          }).catch((error) => {
               const errorCode = error.code;
               const errorMessage = error.message;
          });
          signOut(auth).then(() => {
               // Sign-out successful.
             }).catch((error) => {
               // An error happened.
             });
})