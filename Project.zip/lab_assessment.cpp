#include <iostream>
#include <stack>
#include <list>
#include <algorithm> // Include algorithm header for std::find

using namespace std;

void printStack(stack<int> s) {
    while (!s.empty()) {
        cout << s.top() << " ";
        s.pop();
    }
    cout << endl;
}

void printList(list<int> l) {
    for (auto it = l.begin(); it != l.end(); ++it) {
        cout << *it << " ";
    }
    cout << endl;
}

int main() {
    // Create a stack
    stack<int> myStack;

    // Create a list
    list<int> myList;

    // Insert elements into the stack and list
    for (int i = 1; i <= 5; ++i) {
        myStack.push(i);
        myList.push_back(i);
    }

    // Find size
    cout << "Size of stack: " << myStack.size() << endl;
    cout << "Size of list: " << myList.size() << endl;

    // Insert a new element
    myStack.push(6);
    myList.push_back(6);

    // Delete an element
    myStack.pop();
    myList.pop_back();

    // Demonstrate begin() and end()
    cout << "Stack: ";
    printStack(myStack);
    cout << "List: ";
    printList(myList);

    // Max size (for stack)
    // cout << "Max size of stack: " << myStack.max_size() << endl; // Stack doesn't have max_size()

    // Capacity (for list, since stack doesn't have capacity)
    cout << "Capacity of list: " << myList.max_size() << endl;

    // Reverse
    myList.reverse();
    cout << "Reversed List: ";
    printList(myList);

    // Empty
    cout << "Is stack empty? " << (myStack.empty() ? "Yes" : "No") << endl;
    cout << "Is list empty? " << (myList.empty() ? "Yes" : "No") << endl;

    // Access elements (at(), front(), back())
    cout << "Element at index 2 in list: " << *(next(myList.begin(), 2)) << endl;
    cout << "First element in list: " << myList.front() << endl;
    cout << "Last element in list: " << myList.back() << endl;

    // Erase
    auto it = std::find(myList.begin(), myList.end(), 3);
    if (it != myList.end()) {
        myList.erase(it);
    }
    cout << "List after erasing element 3: ";
    printList(myList);

    // Clear
    myList.clear();
    cout << "List after clear: ";
    printList(myList);

    // Swap
    stack<int> anotherStack;
    for (int i = 6; i <= 10; ++i) {
        anotherStack.push(i);
    }
    myStack.swap(anotherStack);
    cout << "Stack after swap: ";
    printStack(myStack);

    // Merge
    stack<int> mergedStack;
    for (int i = 11; i <= 15; ++i) {
        mergedStack.push(i);
    }
    myStack.swap(mergedStack);
    cout << "Stack after merge: ";
    printStack(myStack);

    return 0;
}
